const express = require('express');
const path = require('path');
const http = require('http');
const socketIo = require('socket.io');
const { SerialPort } = require('serialport');
const { ReadlineParser } = require('@serialport/parser-readline');
const bodyParser = require('body-parser');
const mysql = require('mysql');

// Configurações do servidor Express
const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
    cors: {
        origin: "*", // Permite conexões de qualquer origem
        methods: ["GET", "POST"]
    }
});

// Serve a pasta 'public' como a raiz dos arquivos estáticos
app.use(express.static(path.join(__dirname, 'public')));

// Configurar o parser de JSON para o corpo das requisições
app.use(bodyParser.json());

// Configuração do banco de dados MySQL
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'cinema'
});

db.connect(err => {
    if (err) {
        console.error('Erro ao conectar ao banco de dados MySQL:', err);
        return;
    }
    console.log('Conectado ao banco de dados MySQL');
});

// Inicia o servidor na porta 9999
server.listen(9999, '10.0.0.183', () => {
    console.log(`Servidor rodando no endereço http://10.0.0.183:9999`);
});

// Configurar o parser para ler linhas separadas por '\r\n'
const parser = new ReadlineParser({ delimiter: '\r\n' });

// Configurar a porta serial
const mySerial = new SerialPort({
    path: 'COM5', // Substitua pela porta correta
    baudRate: 9600,
    autoOpen: false
});

// Conectar o parser à porta serial
mySerial.pipe(parser);

// Evento de abertura da conexão
mySerial.on('open', () => {
    console.log('Conexão serial iniciada');
});

// Evento de recebimento de dados
parser.on('data', (data) => {
    console.log('Dados recebidos:', data);
    // Enviar os dados recebidos para todos os clientes conectados via WebSocket
    io.emit('serialData', data);
});

// Evento de erro
mySerial.on('error', (err) => {
    console.error('Erro na conexão serial:', err.message);
});

// Evento de fechamento
mySerial.on('close', () => {
    console.log('Conexão serial fechada');
});

// Abrir a conexão
mySerial.open((err) => {
    if (err) {
        console.error('Erro ao abrir a porta serial:', err.message);
    } else {
        console.log('Porta serial aberta com sucesso');
    }
});

// Configurar o evento de conexão do Socket.IO
io.on('connection', (socket) => {
    console.log('Cliente conectado');
    
    // Receber comandos do cliente e enviar para o Arduino
    socket.on('command', (command) => {
        console.log('Comando recebido:', command);
        if (mySerial.isOpen) {
            mySerial.write(command + '\n'); // Enviar comando via serial
        } else {
            console.error('Porta serial não está aberta.');
        }
    });

    socket.on('disconnect', () => {
        console.log('Cliente desconectado');
    });
});

// Endpoint para validar o código do ingresso
app.post('/validate_ticket', (req, res) => {
    const { code } = req.body;
    
    if (!code) {
        return res.status(400).json({ valid: false, error: 'Código do ingresso não fornecido.' });
    }

    // Consulta ao banco de dados para verificar o código do ingresso
    const query = 'SELECT * FROM assentos WHERE codigo_ingresso = ?'; // Corrigido o nome da tabela
    db.query(query, [code], (err, results) => {
        if (err) {
            console.error('Erro ao consultar o banco de dados MySQL:', err);
            return res.status(500).json({ valid: false, error: 'Erro ao validar o código.' });
        }

        if (results.length > 0) {
            res.json({ valid: true });
        } else {
            res.json({ valid: false });
        }
    });
});

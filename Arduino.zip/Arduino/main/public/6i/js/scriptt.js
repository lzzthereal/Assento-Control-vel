// Obter todos os elementos com a classe "seat"
const assentos = document.querySelectorAll(".seat");

// Função para contar assentos selecionados
function contarAssentosSelecionados() {
    let contador = 0;
    assentos.forEach(assento => {
        if (assento.classList.contains("selected")) {
            contador++;
        }
    });
    return contador;
}

// Exibir o número de assentos selecionados onde desejar
const countElement = document.getElementById('count');
if (countElement) {
    countElement.textContent = contarAssentosSelecionados();
}
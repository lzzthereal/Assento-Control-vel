document.addEventListener('DOMContentLoaded', function() {
    const seatContainer = document.querySelector('.accent-line');
    const seatDetails = document.getElementById('seat-details');
    const countSpan = document.getElementById('count');
    const btnAvancar = document.getElementById('btn-avancar');
    let selectedSeats = [];

    seatContainer.addEventListener('click', function(event) {
        if (event.target.classList.contains('seat')) {
            const seat = event.target;
            const seatId = seat.dataset.seatId;

            // Alternar a seleção do assento
            if (seat.classList.contains('selected')) {
                seat.classList.remove('selected');
                seat.classList.add('available'); // Retornar ao estado disponível
                selectedSeats = selectedSeats.filter(id => id !== seatId);
                countSpan.textContent = parseInt(countSpan.textContent) - 1;
            } else if (seat.classList.contains('available')) {
                seat.classList.remove('available');
                seat.classList.add('selected');
                selectedSeats.push(seatId);
                countSpan.textContent = parseInt(countSpan.textContent) + 1;
            }
        }
    });

    btnAvancar.addEventListener('click', function() {
        if (selectedSeats.length > 0) {
            // Redireciona para a página ingresso.html com IDs dos assentos como parâmetro
            const seatIds = selectedSeats.join(',');
            window.location.href = `ingresso.html?seats=${encodeURIComponent(seatIds)}`;
        } else {
            seatDetails.innerHTML = '<p>Nenhum assento selecionado.</p>';
            seatDetails.style.display = 'block';
        }
    });
});

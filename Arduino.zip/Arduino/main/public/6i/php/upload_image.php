<?php
if (isset($_POST['image'])) {
    $data = $_POST['image'];
    $data = str_replace('data:image/png;base64,', '', $data);
    $data = str_replace(' ', '+', $data);
    $data = base64_decode($data);

    $file = 'uploads/' . uniqid() . '.png'; // Defina o caminho para o diretório onde as imagens serão salvas

    if (file_put_contents($file, $data)) {
        echo json_encode(['url' => $file]);
    } else {
        echo json_encode(['error' => 'Falha ao salvar o arquivo.']);
    }
} else {
    echo json_encode(['error' => 'Imagem não recebida.']);
}
?>
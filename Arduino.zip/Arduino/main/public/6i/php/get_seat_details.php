<?php
header('Content-Type: application/json');

// Habilita a exibição de erros para depuração
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Conectar ao banco de dados
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cinema";

// Cria a conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica a conexão
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Erro de conexão com o banco de dados: ' . $conn->connect_error]);
    exit();
}

// Obtém os IDs dos assentos da URL
$seat_ids = isset($_GET['ids']) ? $_GET['ids'] : '';

if (!empty($seat_ids)) {
    // Cria a consulta SQL
    $ids = explode(',', $seat_ids);
    $ids = array_map('intval', $ids); // Protege contra injeção SQL
    $ids_list = implode(',', $ids);

    $sql = "SELECT codigo_assento, codigo_ingresso FROM assentos WHERE id IN ($ids_list)";
    $result = $conn->query($sql);

    if ($result === false) {
        echo json_encode(['success' => false, 'message' => 'Erro na consulta SQL: ' . $conn->error]);
        exit();
    }

    $seats = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $seats[] = $row;
        }
        echo json_encode(['success' => true, 'data' => $seats]);
    } else {
        echo json_encode(['success' => true, 'data' => []]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Nenhum assento selecionado.']);
}

// Fecha a conexão
$conn->close();
?>

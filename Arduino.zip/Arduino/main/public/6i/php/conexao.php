<?php 
$conexao = new mysqli("localhost","root","","cinema");
 if ($conexao -> connect_error){
    die ("Erro de conexão:". $conexao -> connect_error);
}
?>
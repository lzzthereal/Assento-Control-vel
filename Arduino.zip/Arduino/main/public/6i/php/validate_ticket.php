<?php
header('Content-Type: application/json');

// Conecta ao banco de dados (substitua com suas credenciais)
$servername = "localhost"; // ou o IP do seu servidor de banco de dados
$username = "root"; // ou o usuário do seu banco de dados
$password = ""; // ou a senha do seu banco de dados
$dbname = "cinema"; // ou o nome do seu banco de dados

// Cria a conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica a conexão
if ($conn->connect_error) {
    die(json_encode(['valid' => false, 'error' => 'Erro de conexão: ' . $conn->connect_error]));
}

// Obtém o código do ingresso do formulário
$code = $_POST['ticket-code'];

// Prepara e executa a consulta
$stmt = $conn->prepare("SELECT * FROM assentos WHERE codigo_ingresso = ?");
$stmt->bind_param("s", $code);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Código de ingresso encontrado
    echo json_encode(['valid' => true]);
} else {
    // Código de ingresso não encontrado
    echo json_encode(['valid' => false]);
}

// Fecha a conexão
$stmt->close();
$conn->close();
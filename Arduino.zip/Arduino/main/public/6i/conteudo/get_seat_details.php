<?php
header('Content-Type: application/json');

// Conectar ao banco de dados
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cinema";

// Cria a conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica a conexão
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Obtém os IDs dos assentos da URL
$seat_ids = isset($_GET['ids']) ? $_GET['ids'] : '';

if (!empty($seat_ids)) {
    // Cria a consulta SQL
    $ids = explode(',', $seat_ids);
    $ids = array_map('intval', $ids); // Protege contra injeção SQL
    $ids_list = implode(',', $ids);

    $sql = "SELECT codigo_assento, codigo_ingresso FROM assentos WHERE id IN ($ids_list)";
    $result = $conn->query($sql);

    $seats = [];
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $seats[] = $row;
        }
        echo json_encode(['success' => true, 'seats' => $seats]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Nenhum detalhe encontrado.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'IDs dos assentos não fornecidos.']);
}

// Fecha a conexão
$conn->close();
?>
